using Enki;
using System;


class Index : Mod {
    public override void OnLoad() {
        Console.WriteLine("Hello World!. This was Printed from Within a Mod");       
    }
}